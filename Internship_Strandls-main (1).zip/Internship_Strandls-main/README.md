# Internship_Strandls

Contains details on practice and work related to my internship at [Strand Life Sciences](https://strandls.com/)

## Documents

1. Internship project ideas: https://docs.google.com/document/d/1bC6LI_Jpktj3MDpT40zK03Y4vxjf-xNzmuAQE0DeliQ/edit#heading=h.k1uh6cezvzl0
2. Details on variant identification service: https://docs.google.com/document/d/1ITBjTGb6lggWWvQJixW0MuLTN7CmB-WjGpxGEHnMGz4/edit
3. Documentation: https://docs.google.com/document/d/1MtUNjfo8M8Md9Ys0nFBT_mXQU81rhwJftwGXLdqqcQA/edit?usp=sharing


## My Practice

1. Git & GitHub: May 19, 2023 - Practiced git and made a cheat sheet
2. MySQL: https://www.hackerrank.com/user_purpose1997
