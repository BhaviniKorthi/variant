package packages;
public class my_package {


    public static void main(String[] args) {
        System.out.println("hello, you can use this package to test your code");
    }
    
}
