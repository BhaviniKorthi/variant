class VariantDTO:
    def __init__(self, variant_id, variant_info, message):
        self.variant_id = variant_id
        self.variant_info = variant_info
        self.Message = message 
