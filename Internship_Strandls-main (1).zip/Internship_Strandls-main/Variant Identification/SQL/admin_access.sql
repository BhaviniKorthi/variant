ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Srikar@420';
